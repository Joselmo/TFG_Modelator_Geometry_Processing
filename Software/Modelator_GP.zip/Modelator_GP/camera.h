/*
Necesita 3 vectores
  v posicion - indica donde esta situada la camara
  v dirección/objetivo - indica a donde mira la camara
  v UP  - Indica la inclinación lateral de la camara por defecto igual al eje y (0,1,0)
Para las transformaciones utilizar glutLookAt Contenido en un método que sirva de interfaz
para escena, por ejemplo "aplicar"
Para mover es
pos += incremento
Por ejemplo con el ratón modificamos la dirección de la camara con v_direccion/objetivo o al vector UP
*/
#ifndef _CAMERA_H
#define _CAMERA_H

#include <GL/gl.h>
#include <GL/glut.h>
#include <vector>


#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


#include <iostream>

using namespace std;

class Camera{
private:
  vector<GLdouble> eye;
  vector<GLdouble> at;
  vector<GLdouble> up;
  GLdouble left, right, bottom, top, near, far;             // Opciones de la lente
  bool perspective;

  glm::vec3 position;
  glm::vec3 viewDirection;
  const glm::vec3 UP;
  glm::vec2 oldMousePosition;


public:
  Camera();
  // Constructores de materiales solidos
  Camera(bool perspective, GLdouble lens[6], GLdouble position[9]);

  void setLens(GLdouble left, GLdouble right, GLdouble bottom, GLdouble top,
               GLdouble near, GLdouble far);

  void setLens(GLdouble lens[6]);

  void setPosition(GLdouble eyeX, GLdouble eyeY, GLdouble eyeZ,
                   GLdouble atX, GLdouble atY, GLdouble atZ,
                   GLdouble upX, GLdouble upY, GLdouble upZ);

  void setPosition(GLdouble position[6]);

  void setPosition(GLdouble eyeX,GLdouble eyeY, GLdouble eyeZ);

  void setProjection();

  void setLookAt();

  void setPerspective(bool state);

  void girar(int x, int y);
  void girar(int x, int y,int z);
  //void examinar(int x, int y);
  void zoom(int direction);

  glm::mat4 getWorldToViewMatrix() const;
  void mouseUpdate(const glm::vec2& newMousePosition);

};
#endif
