#include "mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
{
/*
    Front_plane=50;
    Back_plane=2000;
    Observer_distance = 50;//2*Front_plane;
    Observer_angle_x = Observer_angle_y=0;
    ejes.changeAxisSize(15000);

    setSurfaceType(QWindow::OpenGLSurface);
    QSurfaceFormat format;
    format.setProfile(QSurfaceFormat::CompatibilityProfile);
    format.setVersion(4,4);
    setFormat(format);

    context = new QOpenGLContext;
    context->setFormat(format);
    context->create();
    context->makeCurrent(this);

    openGLFuncions = context->functions();

    m_transform.translate(0.0f, 0.0f, -5.0f);


    rotation = 10;
    cubo.createGeometry();
    cubo.setColorAll(1,0.65,0);

    Observer_angle_x+=30;
    Observer_angle_y-=10;
    mode_view = 0;
    mesh_scale = 5.0;

    Observer_position_x = 0;
    Observer_position_y = 0;

    pos_cam_x = 0;
    pos_cam_y = 0;
    pos_cam_z = 200;


    //InfoDialog info;
    //info.setWindowTitle("Información");
    //info.exec();
    PLYReader pread;
    Malla malla1;
    pread.readPLY(malla1,"beethoven.ply");
    object.setMesh(malla1);

    // object.createGeometry();
    object.setColorAll(1,0.65,0);

    std::cout<< "iniciar clase"<<std::endl;
    */
    m_transform.translate(0.0f, 0.0f, -5.0f);
}

MainWindow::~MainWindow()
{

}


void MainWindow::initializeGL()
{

    // Initialize OpenGL Backend
    initializeOpenGLFunctions();
    connect(context(), SIGNAL(aboutToBeDestroyed()), this, SLOT(teardownGL()), Qt::DirectConnection);
    connect(this, SIGNAL(frameSwapped()), this, SLOT(update()));
    printVersionInformation();

    // Set global information
    glClearColor(1,1,1,1);// se indica cual sera el color para limpiar la ventana	(r,v,a,al)

    glEnable(GL_DEPTH_TEST);	// se habilita el z-bufer
    glEnable(GL_CULL_FACE);   // Habilita la cara frontal solo

    // Application-specific initialization
    {
      // Create Shader (Do not release until VAO is created)
      m_program = new QOpenGLShaderProgram();
      m_program->addShaderFromSourceFile(QOpenGLShader::Vertex, ":/shaders/simple.vert");
      m_program->addShaderFromSourceFile(QOpenGLShader::Fragment, ":/shaders/simple.frag");
      m_program->link();
      m_program->bind();

      // Cache Uniform Locations
      u_modelToWorld = m_program->uniformLocation("modelToWorld");
      u_worldToCamera = m_program->uniformLocation("worldToCamera");
      u_cameraToView = m_program->uniformLocation("cameraToView");

      // Create Buffer (Do not release until VAO is created)
      m_vertex.create();
      m_vertex.bind();
      m_vertex.setUsagePattern(QOpenGLBuffer::StaticDraw);
      m_vertex.allocate(cubo.getMesh().getVertexesV(), sizeof(cubo.getMesh().getVertexesV()));


      // Create Vertex Array Object
      m_object.create();
      m_object.bind();
      m_program->enableAttributeArray(0);
      m_program->enableAttributeArray(1);
      m_program->setAttributeBuffer(0, GL_FLOAT, Vertex::positionOffset(), Vertex::PositionTupleSize, Vertex::stride());
      m_program->setAttributeBuffer(1, GL_FLOAT, Vertex::colorOffset(), Vertex::ColorTupleSize, Vertex::stride());

      // Release (unbind) all
      m_object.release();
      m_vertex.release();
      m_program->release();
    }

    /*
    Width=this->width()/10;
    Height=this->height()/10;


    this->change_projection();
    glViewport(0,0,this->width(),this->height());
    connect(this, SIGNAL(frameSwapped()), this, SLOT(update()));
    resizeGL(this->width(),this->height());
    std::cout<< "iniciar opengl"<<std::endl;
    */
}



void MainWindow::paintGL()
{
    // Clear
      glClear(GL_COLOR_BUFFER_BIT);

      // Render using our shader
      m_program->bind();
      m_program->setUniformValue(u_worldToCamera, m_camera.toMatrix());
      m_program->setUniformValue(u_cameraToView, m_projection);
      {
        m_object.bind();
        m_program->setUniformValue(u_modelToWorld, m_transform.toMatrix());
        glDrawArrays(GL_TRIANGLES, 0, sizeof(sg_vertexes) / sizeof(sg_vertexes[0]));
        m_object.release();
      }
      m_program->release();


    /*
    glClear(GL_DEPTH_BUFFER_BIT ); // Limpiar la pantalla
    change_observer();
    // Draw axis
    ejes.draw();
    // Draw Objects
    object.draw(GL_FRONT,mode_view,mesh_scale);
    //cubo.draw(GL_FRONT,mode_view,mesh_scale);

    //Draw Mode Picker
    if(MODE == PICKER){
        //sphere.draw(GL_FRONT,0,2);
    }
    */
}



void MainWindow::update()
{
    // Update input
    Input::update();

    // Camera Transformation
    if (Input::keyPressed(Qt::Key_Up)){
        pos_cam_y++;
    }
    if (Input::keyPressed(Qt::Key_Down)){
        pos_cam_y--;
    }
    if (Input::keyPressed(Qt::Key_Left)){
        pos_cam_x--;
    }
    if (Input::keyPressed(Qt::Key_Right)){
        pos_cam_x++;
    }
    if (Input::keyPressed(Qt::Key_PageDown)){
        pos_cam_z--;
    }
    if (Input::keyPressed(Qt::Key_PageUp)){
        pos_cam_z++;
    }
    if (Input::keyPressed(Qt::Key_F1)){
        pos_cam_x = 0; pos_cam_y= 0; pos_cam_z = 200;camaraActiva=0;
    }
    if (Input::keyPressed(Qt::Key_F2)){
        pos_cam_x = 0; pos_cam_y= 200; pos_cam_z = 0;
    }
    if (Input::keyPressed(Qt::Key_F3)){
        pos_cam_x = 200; pos_cam_y= 0; pos_cam_z = 0;
    }

    if (Input::keyReleased(Qt::Key_1)){
        mode_view = 0;
        std::cout<<"Modo visualización: relleno"<<std::endl;
    }
    if (Input::keyReleased(Qt::Key_2)){
        mode_view = 1;
        std::cout<<"Modo visualización: puntos"<<std::endl;
    }
    if (Input::keyReleased(Qt::Key_3)){
        mode_view = 2;
        std::cout<<"Modo visualización: alambre"<<std::endl;
    }
    if (Input::keyReleased(Qt::Key_Plus)){
        mesh_scale++;
        std::cout<<"Escalado x"<<mesh_scale<<std::endl;
    }
    if (Input::keyReleased(Qt::Key_Minus)){
        mesh_scale--;
        std::cout<<"Escalado x"<<mesh_scale<<std::endl;
    }
    if (Input::keyReleased(Qt::Key_9)){
        //setModePicket();
        std::cout<<"Modo seleccionar"<<std::endl;
    }

    if(Input::buttonPressed(Qt::RightButton)){ //click derecho
        clickRaton(MOUSE_RIGHT_BUTTON,true,Input::mousePosition().x(),
                   Input::mousePosition().y());
    }


    // Schedule a redraw
    QOpenGLWindow::update();
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (event->isAutoRepeat())
    {
        event->ignore();
    }
    else
    {
        Input::registerKeyPress(event->key());
    }
}

void MainWindow::keyReleaseEvent(QKeyEvent *event)
{
    if (event->isAutoRepeat())
    {
        event->ignore();
    }
    else
    {
        Input::registerKeyRelease(event->key());
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    std::cout<< "pulsado ratón"<<event->button()<<std::endl;

    Input::registerMousePress(event->button());
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    Input::registerMouseRelease(event->button());


}

void MainWindow::teardownGL()
{

}


void MainWindow::paintEvent(QPaintEvent *event)
{
    paintGL();

}

//**************************************************************************
// Funcion para definir la transformacion de proyeccion
//***************************************************************************

void MainWindow::change_projection(){
    camaras[camaraActiva].setProjection();
}


void MainWindow::resizeGL(int w, int h)
{
    change_projection();
    Width=w/10;
    Height=h/10;
    glViewport(0,0,w,h);
}


void MainWindow::resizeEvent(QResizeEvent *event)
{
    resizeGL(this->width(),this->height());
    this->update();
}


//**************************************************************************
// Funcion para definir la transformacion de vista (posicionar la camara)
//***************************************************************************

void MainWindow::change_observer() {

    // posicion del observador
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    if(estadoRaton != MODO_EXAMINAR){
        camaras[camaraActiva].setPosition(pos_cam_x,pos_cam_y,pos_cam_z);
    }
    //camaras[camaraActiva].setLookAt();
}



//**************************************************************************
// Funcion que controla los eventos producidos por el raton
//***************************************************************************
void MainWindow::clickRaton(int boton,bool estado,int x,int y){
    if(boton == MOUSE_RIGHT_BUTTON){
        std::cout << "Click derecho ";
        if(estado){  // Se pulsa el botón, por lo que se entra en el estado "moviendo camara"
            std::cout <<"pulsado"<< std::endl;
            xant = x;
            yant = y;
            if(estadoRaton == -1)
                estadoRaton = MOVIENDO_CAMARA_FIRSTPERSON;
        }else{ // Se levanta el botón, por lo que se sale del estado "moviendo camara"
            //  camaras[camaraActiva].girar(x-xant,y-yant);
            std::cout <<"soltado"<< std::endl;
            if(estadoRaton == MOVIENDO_CAMARA_FIRSTPERSON)
                estadoRaton = -1;
        }
    }else if(boton == MOUSE_LEFT_BUTTON){
        std::cout << "Click izquierdo ";
        if(estado){  // Se pulsa el botón, por lo que se entra en el estado "moviendo camara"
            if(estadoRaton != MODO_EXAMINAR){
                //pick(x,y);
                std::cout <<"click izquierdo"<< std::endl;
            }
            std::cout <<"pulsado"<< std::endl;
        }else{
            xant = x;
            yant = y;
            estadoRaton = (estadoRaton==MODO_EXAMINAR)?-1:MODO_EXAMINAR;  // Si estaba activado lo desactivo y si no estaba activado lo activo

        }
    }
}


//**************************************************************************
// Funcion que controla los eventos producidos por el movimiento raton
//***************************************************************************

void MainWindow::ratonMovido(int x,int y){

    if(estadoRaton == MOVIENDO_CAMARA_FIRSTPERSON){
        //std::cout<< "moviendo "<< x <<"-"<<y<<std::endl;
        //camaras[camaraActiva].girar(x-xant,y-yant);
        x -= xant;
        y -= yant;
        camaras[camaraActiva].girar(x,-y);
    }else if(estadoRaton == MODO_EXAMINAR){
        //std::cout<< "moviendo "<< x <<"-"<<y<<std::endl;
        //camaras[camaraActiva].girar(x-xant,y-yant);
        x -= xant;
        y -= yant;
        camaras[camaraActiva].setPosition(x,-y,pos_cam_z);
    }
}

//**************************************************************************
// Funcion que controla los eventos producidos por el movimiento raton
//***************************************************************************

void MainWindow::ratonRueda(int direction){
    //camaras[camaraActiva].zoom(direction);
    pos_cam_z += direction;
}


