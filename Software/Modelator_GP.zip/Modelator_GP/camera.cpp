
#include "camera.h"

Camera::Camera(){
  eye.resize(3);
  at.resize(3);
  up.resize(3);
  left  = 0;  // Opciones de la lente
  right = 0;
  bottom= 0;
  top   = 0;
  near  = 0;
  far   = 0;

  perspective = true;
}


Camera::Camera(bool perspective, GLdouble lens[6], GLdouble position[9]){
  this->perspective = perspective;
  left   = lens[0];
  right  = lens[1];
  bottom = lens[2];
  top  = lens[3];
  near = lens[4];
  far  = lens[5];

  eye[0] = position[0];
  eye[1] = position[1];
  eye[2] = position[2];
  at[0]  = position[3];
  at[1]  = position[4];
  at[2]  = position[5];
  up[0]  = position[6];
  up[1]  = position[7];
  up[2]  = position[8];

}

void Camera::setLens(GLdouble left, GLdouble right, GLdouble bottom, GLdouble top,
               GLdouble near, GLdouble far){
  this->left   = left;
  this->right  = right;
  this->bottom = bottom;
  this->top  = top;
  this->near = near;
  this->far  = far;
}

void Camera::setLens(GLdouble lens[6]){
  setLens(lens[0],lens[1],lens[2],lens[3],lens[4],lens[5]);
}

void Camera::setPosition(GLdouble eyeX, GLdouble eyeY, GLdouble eyeZ,
                   GLdouble atX, GLdouble atY, GLdouble atZ,
                   GLdouble upX, GLdouble upY, GLdouble upZ){

  eye[0] = eyeX;
  eye[1] = eyeY;
  eye[2] = eyeZ;
  at[0]  = atX;
  at[1]  = atY;
  at[2]  = atZ;
  up[0]  = upX;
  up[1]  = upY;
  up[2]  = upZ;

}

void Camera::setPosition(GLdouble position[6]){
  eye[0] = position[0];
  eye[1] = position[1];
  eye[2] = position[2];
  at[1]  = position[3];
  at[2]  = position[4];
  at[3]  = position[5];
  up[0]  = position[6];
  up[1]  = position[7];
  up[2]  = position[8];
}

void Camera::setPosition(GLdouble eyeX,GLdouble eyeY, GLdouble eyeZ){
  eye[0] = eyeX;
  eye[1] = eyeY;
  eye[2] = eyeZ;
}

void Camera::setProjection(){
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  if(perspective)
    glFrustum(left,right,bottom,top,near,far);
  else
    glOrtho(left,right,bottom,top,near,far);


}

void Camera::setLookAt(){
  //gluLookAt(eye[0],eye[1],eye[2],  at[0],at[1],at[2], up[0],up[1],up[2]);

}


void Camera::setPerspective(bool state){
  perspective=state;
}

void Camera::girar(int x, int y){
//  at[0] += (x>0)?1:-1;
//  at[1] += (y>0)?1:-1;
  at[0]=x;
  at[1]=y;
}

void Camera::girar(int x, int y,int z){
//  at[0] += (x>0)?1:-1;
//  at[1] += (y>0)?1:-1;
  at[0]=x;
  at[1]=y;
  at[2]=z;
}

void Camera::zoom(int direction){
  at[2] += direction;

}

glm::mat4 Camera::getWorldToViewMatrix() const{
    return glm::lookAt(position,position + viewDirection, UP);
}

void Camera::mouseUpdate(const glm::vec2 &newMousePosition)
{
    glm::vec2 mouseDelta = newMousePosition - oldMousePosition;
    viewDirection = glm::mat3(glm::rotate(mouseDelta.x, UP)) * viewDirection;
    oldMousePosition = newMousePosition;
}
